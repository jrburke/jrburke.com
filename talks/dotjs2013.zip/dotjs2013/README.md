Super VanJS Nov 2013 talk

