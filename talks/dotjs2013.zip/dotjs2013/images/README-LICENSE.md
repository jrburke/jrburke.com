The images are from http://www.shutterstock.com, and purchased for use
in this presentation. They are not for reuse by others, and have restrictions.
