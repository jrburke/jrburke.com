define(function (require) {
    var element = require('element');

    element.ready(function() {
        console.log('FINISHED LOADING');
    });
});
